import asyncio
import os
import re
import json
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any

import requests
from fastapi import FastAPI, HTTPException, Query, Body, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from bson import ObjectId
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

# –––––––– OneSignal Setup ––––––––
ONESIGNAL_APP_ID = "q45eb09e1-b8d5-4b58-890d-7b4eee3b21f4"
ONESIGNAL_REST_API_KEY = os.environ.get("ONESIGNAL_REST_API_KEY")
if not ONESIGNAL_REST_API_KEY:
    print("WARNING: ONESIGNAL_REST_API_KEY environment variable not found. OneSignal notifications will not work.")

# –––––––– MongoDB Setup ––––––––
mongo_uri = "mongodb+srv://dfi-user:UwXxlbp6C3uZTE50@dfisaudi.e7wbnvh.mongodb.net/?retryWrites=true&w=majority&appName=DFISaudi"
client = MongoClient(mongo_uri)

# App DB/collections
db = client["DFIchecker"]
user_medications_col = db["user_medication_list"]
drug_food_interactions_col = db["drug_food_interactions"]
user_onesignal_tokens_col = db["user_onesignal_tokens"]
feedback_collection = client["UserFeedBack"]["interaction_feedback"]

# Knowledge sources
sfda_col = client["SFDA"]["SFDA_drugs"]
food_interactions_col = client["knowledge"]["food_interactions"]
herb_interactions_col = client["knowledge"]["herb_interactions"]
drug_herb_map_col = client["knowledge"]["drug_herb_map"]  # canonical_scientific + sfda_drug_ids[]

# –––––––– FastAPI Setup ––––––––
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# –––––––– Scheduler Setup ––––––––
scheduler = AsyncIOScheduler()

@app.on_event("startup")
async def startup_event():
    scheduler.start()
    scheduler.add_job(
        send_daily_reminder,
        CronTrigger(hour=10, minute=0),
        id="daily_reminder",
        replace_existing=True,
    )
    print("Scheduler started - Daily reminders set for 10 AM")

@app.on_event("shutdown")
async def shutdown_event():
    scheduler.shutdown()

# –––––––– OneSignal Helper Functions ––––––––
async def send_onesignal_notification(user_ids: List[str], title: str, body: str, data: dict | None = None):
    if not ONESIGNAL_REST_API_KEY:
        print("OneSignal REST API Key not configured. Skipping notification.")
        return

    user_tokens_docs = user_onesignal_tokens_col.find({"user_id": {"$in": user_ids}})
    player_ids = [doc.get("player_id") for doc in user_tokens_docs if "player_id" in doc]
    if not player_ids:
        print(f"No OneSignal player IDs found for users {user_ids}. Cannot send notification.")
        return

    notification_data = {
        "app_id": ONESIGNAL_APP_ID,
        "include_player_ids": player_ids,
        "headings": {"en": title, "ar": title},
        "contents": {"en": body, "ar": body},
    }
    if data:
        notification_data["data"] = data

    headers = {
        "Content-Type": "application/json; charset=utf-8",
        "Authorization": f"Basic {ONESIGNAL_REST_API_KEY}",
    }

    try:
        response = requests.post(
            "https://onesignal.com/api/v1/notifications",
            headers=headers,
            data=json.dumps(notification_data),
            timeout=20,
        )
        if response.status_code == 200:
            print(f"OneSignal: Successfully sent notification to users {user_ids}")
            print(f"Response: {response.json()}")
        else:
            print(f"OneSignal Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"OneSignal Error: Failed to send notification: {e}")

async def send_interaction_alert(user_id: str, interaction_details: dict):
    title = "سالم"
    body = "سلامتك اهم، شيّك إذا في تعارضات مع دواك"
    data = {
        "type": "new_interaction",
        "interaction_id": str(interaction_details.get("_id")),
        "drug_name": interaction_details.get("drug_trade_name", ""),
        "food_name": interaction_details.get("interaction_food", ""),
    }
    await send_onesignal_notification([user_id], title, body, data)

async def send_daily_reminder():
    print("Running daily reminder check…")
    try:
        today = datetime.now(timezone.utc)
        pipeline = [
            {
                "$match": {
                    "$or": [
                        {"drug_duration_end_date": None},
                        {"drug_duration_end_date": {"$gte": today}},
                    ]
                }
            },
            {"$group": {"_id": "$user_id", "interaction_count": {"$sum": 1}}},
        ]
        users_with_interactions = list(drug_food_interactions_col.aggregate(pipeline))
        user_ids = [user["_id"] for user in users_with_interactions]
        if user_ids:
            title = "سالم"
            body = "سلامتك اهم، شيّك إذا في تعارضات مع دواك"
            data = {"type": "daily_reminder"}
            await send_onesignal_notification(user_ids, title, body, data)
            print(f"Sent daily reminder to {len(user_ids)} users")
        else:
            print("No users with active interactions found for daily reminder")
    except Exception as e:
        print(f"Error in daily reminder: {e}")

# –––––––– Pydantic Models ––––––––
class ProcessRequest(BaseModel):
    user_id: str

class Medication(BaseModel):
    user_id: str
    sfda_drug_id: str
    drug_trade_name: str
    drug_scientific_name: str
    drug_duration_start_date: datetime
    drug_duration_end_date: Optional[datetime] = None
    processed: int
    integrated: bool
    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}

class Feedback(BaseModel):
    user_id: str
    drug_id: str
    interaction_food: str
    description: str
    severity: str
    drug_trade_name: str
    drug_duration_end_date: datetime
    user_answer: str
    created_at: datetime

# –––––––– Helper Functions ––––––––
def find_scientific_names(trade_name: str) -> List[str]:
    """
    Returns a de-duplicated list of scientific name fragments for a trade name.
    """
    docs = list(
        sfda_col.find(
            {"trade_name": {"$regex": f"^{re.escape(trade_name)}$", "$options": "i"}}
        )
    )
    names: List[str] = []
    for doc in docs:
        sci = doc.get("scientific_name", "") or ""
        parts = [x.strip() for x in sci.split(",") if x.strip()]
        names.extend(parts)
    return list(set(names))

def find_food_interactions(scientific_name: str) -> List[Dict[str, Any]]:
    """
    Lookup food interactions in knowledge.food_interactions by full/substring match.
    """
    return list(
        food_interactions_col.find(
            {"drug_name": {"$regex": re.escape(scientific_name), "$options": "i"}}
        )
    )

# ---------- Herb interaction helpers ----------
# Canonical → synonyms (to bridge paracetamol/acetaminophen, etc.)
CANON_SYNONYMS: Dict[str, List[str]] = {
    "paracetamol": ["paracetamol", "acetaminophen"],
    "acetaminophen": ["acetaminophen", "paracetamol"],
    # Add more pairs if you expand the map later
}

def dips_ar(value: Optional[str]) -> str:
    v = (value or "").strip().lower()
    if v == "probable":
        return "مرجّح"
    if v == "possible":
        return "احتمال"
    if v == "doubtful":
        return "غير مؤكد"
    return ""

def build_herb_description_ar(herb: str, drug: str, dips_result: Optional[str], evidence: Optional[str]) -> str:
    """
    Short, natural Saudi Arabic message.
    """
    dips_txt = dips_ar(dips_result)
    if (evidence or "").upper() == "PI":
        # PI entries may not have a DIPS result
        return f"حسب النشرة الدوائية، قد يتعارض {herb} مع {drug}. استشر طبيبك أو صيدليتك."
    if dips_txt:
        return f"قد يتعارض {herb} مع {drug} (التقييم: {dips_txt}). نصيحة: راجع طبيبك أو صيدليتك."
    # Fallback
    return f"قد يوجد تعارض بين {herb} و{drug}. يُنصح بمراجعة المختص."

def canonical_from_sfda_id(sfda_drug_id: str) -> Optional[str]:
    """
    Find the canonical scientific name for a given SFDA ID using knowledge.drug_herb_map.
    """
    if not sfda_drug_id:
        return None
    doc = drug_herb_map_col.find_one({"sfda_drug_ids": sfda_drug_id})
    if not doc:
        return None
    return doc.get("canonical_scientific")

def herb_hits_for_canonical(canonical: str) -> List[Dict[str, Any]]:
    """
    Pull matching herb interactions for a canonical name (with synonyms).
    """
    if not canonical:
        return []
    candidates = CANON_SYNONYMS.get(canonical.lower(), [canonical])
    or_terms = [{"drug_name": {"$regex": f"^{re.escape(term)}$", "$options": "i"}} for term in candidates]
    return list(herb_interactions_col.find({"$or": or_terms}))

# –––––––– Routes ––––––––
@app.get("/autocomplete")
def autocomplete(q: str = Query(...)):
    try:
        regex = {"$regex": q, "$options": "i"}
        docs = list(
            sfda_col.find(
                {"$or": [{"trade_name": regex}, {"scientific_name": regex}]},
                {"_id": 0, "sfda_drug_id": 1, "trade_name": 1, "scientific_name": 1},
            ).limit(15)
        )
        results = []
        for doc in docs:
            if q.lower() in (doc.get("trade_name", "").lower()):
                results.append(
                    {
                        "type": "trade_name",
                        "trade_name": doc.get("trade_name", ""),
                        "scientific_name": doc.get("scientific_name", ""),
                        "sfda_drug_id": doc.get("sfda_drug_id", ""),
                    }
                )
            if q.lower() in (doc.get("scientific_name", "").lower()):
                results.append(
                    {
                        "type": "scientific_name",
                        "scientific_name": doc.get("scientific_name", ""),
                        "trade_name": doc.get("trade_name", ""),
                        "sfda_drug_id": doc.get("sfda_drug_id", ""),
                    }
                )
        return {"results": results}
    except Exception as e:
        print("Autocomplete error:", e)
        return {"error": str(e)}

@app.get("/autofill")
def autofill(input_name: str):
    try:
        drug = sfda_col.find_one(
            {
                "$or": [
                    {"trade_name": {"$regex": f"^{input_name}$", "$options": "i"}},
                    {"scientific_name": {"$regex": f"^{input_name}$", "$options": "i"}},
                ]
            },
            {"_id": 0, "sfda_drug_id": 1, "trade_name": 1, "scientific_name": 1},
        )
        return drug if drug else {"error": "Name not found in SFDA dataset."}
    except Exception as e:
        print("Autofill error:", e)
        return {"error": str(e)}

@app.get("/user/{user_id}/has-interactions")
def has_interactions(user_id: str):
    try:
        today = datetime.now(timezone.utc)
        query = {
            "user_id": user_id,
            "$or": [
                {"drug_duration_end_date": None},
                {"drug_duration_end_date": {"$gte": today}},
            ],
        }
        count = drug_food_interactions_col.count_documents(query)
        return {"hasInteractions": count > 0}
    except Exception as e:
        print("Error checking interactions:", e)
        return {"error": str(e)}

def store_interaction(interaction: Dict[str, Any], user_id: str, trade_name: str, duration_end: Optional[datetime]):
    """
    Stores a single interaction doc in DFIchecker.drug_food_interactions.
    Deduped on (user_id, trade_name, interaction_food).
    """
    entry = {
        "user_id": user_id,
        "drug_id": interaction.get("drug_id", ""),  # keep same field; for herbs we leave ""
        "interaction_food": (interaction.get("interaction_food") or "").strip(),
        "description": interaction.get("description", ""),
        "severity": interaction.get("severity", "N/A"),
        "drug_trade_name": trade_name,
        "drug_duration_end_date": duration_end,
        "submitted": False,
    }

    try:
        # Simple de-dupe
        existing = drug_food_interactions_col.find_one(
            {"user_id": user_id, "drug_trade_name": trade_name, "interaction_food": entry["interaction_food"]}
        )
        if existing:
            print(f"DEBUG: Skipping duplicate interaction for {user_id}/{trade_name}/{entry['interaction_food']}")
            return

        print(f"DEBUG: Inserting interaction: {entry}")
        result = drug_food_interactions_col.insert_one(entry)

        if result.inserted_id:
            entry["_id"] = result.inserted_id
            asyncio.create_task(send_interaction_alert(user_id, entry))

    except DuplicateKeyError:
        pass
    except Exception as e:
        print(f"Error in store_interaction (non-duplicate): {e}")

def process_user_medications(user_id: str):
    """
    Processes unprocessed user meds:
    - Finds FOOD interactions via knowledge.food_interactions
    - Finds HERB interactions via knowledge.drug_herb_map + knowledge.herb_interactions
    Stores everything into DFIchecker.drug_food_interactions with Arabic messages for herbs.
    """
    print(f"Processing medications for user: {user_id}")
    user_meds = list(user_medications_col.find({"user_id": user_id, "processed": 0}))

    if not user_meds:
        return {"message": "No unprocessed medications for this user."}

    stored_count = 0

    for med in user_meds:
        trade_name = (med.get("drug_trade_name") or "").strip()
        sfda_id = (med.get("sfda_drug_id") or "").strip()
        duration_end = med.get("drug_duration_end_date")

        if not trade_name:
            continue

        # 1) FOOD interactions as before
        scientific_names = find_scientific_names(trade_name)
        for sci in scientific_names:
            food_hits = find_food_interactions(sci)
            for inter in food_hits:
                store_interaction(inter, user_id, trade_name, duration_end)
                stored_count += 1

        # 2) HERB interactions using sfda_id → canonical → herb_interactions
        canonical = canonical_from_sfda_id(sfda_id)
        if canonical:
            herb_hits = herb_hits_for_canonical(canonical)
            for h in herb_hits:
                herb_name = h.get("herb_name", "").strip()
                drug_name = h.get("drug_name", "").strip()
                dips_result = h.get("dips_result", "")
                evidence = h.get("evidence", "")

                # Compose an interaction doc compatible with store_interaction
                herb_doc = {
                    "drug_id": "",  # keep empty to avoid mixing with DrugBank IDs
                    "interaction_food": herb_name,  # UI expects "food" field; we put herb here
                    "description": build_herb_description_ar(herb_name, drug_name, dips_result, evidence),
                    "severity": "N/A",
                }
                store_interaction(herb_doc, user_id, trade_name, duration_end)
                stored_count += 1

        # Mark med processed
        user_medications_col.update_one({"_id": med["_id"]}, {"$set": {"processed": 1}})

    return {"message": f"Processed successfully. {stored_count} interactions stored."}

@app.post("/process/")
def process_user(request: ProcessRequest):
    try:
        result = process_user_medications(request.user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/interactions")
def get_user_interactions(user_id: str = Query(...)):
    try:
        results = list(drug_food_interactions_col.find({"user_id": user_id}))
        for r in results:
            r["_id"] = str(r["_id"])
            r["submitted"] = r.get("submitted", False)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/register_onesignal_token/")
async def register_onesignal_token(request: Request):
    try:
        data = await request.json()
        user_id = data.get("user_id")
        player_id = data.get("player_id")
        if not user_id or not player_id:
            raise HTTPException(status_code=400, detail="user_id and player_id are required")
        user_onesignal_tokens_col.update_one(
            {"user_id": user_id},
            {"$set": {"player_id": player_id, "updated_at": datetime.now(timezone.utc)}},
            upsert=True,
        )
        print(f"OneSignal player ID registered for user {user_id}: {player_id}")
        return {"message": "OneSignal player ID registered successfully"}
    except Exception as e:
        print(f"Error registering OneSignal token: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/test_notification/")
async def test_notification(request: Request):
    try:
        data = await request.json()
        user_id = data.get("user_id", "1")
        title = "سالم"
        body = "سلامتك اهم، شيّك إذا في تعارضات مع دواك"
        await send_onesignal_notification([user_id], title, body, {"type": "test"})
        return {"message": "Test notification sent"}
    except Exception as e:
        print(f"Error sending test notification: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/submit_feedback/")
async def submit_feedback(request: Request):
    try:
        body = await request.json()
        feedback_data = body.get("feedback")
        interaction_id = body.get("interaction_id")
        if isinstance(interaction_id, str):
            interaction_id = ObjectId(interaction_id)

        feedback = Feedback(**feedback_data)
        feedback_dict = feedback.dict()
        feedback_dict["created_at"] = datetime.now()
        result = feedback_collection.insert_one(feedback_dict)

        if interaction_id:
            drug_food_interactions_col.update_one(
                {"_id": ObjectId(interaction_id)},
                {"$set": {"submitted": True}},
            )
        return {"message": "Feedback submitted successfully", "inserted_id": str(result.inserted_id)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error submitting feedback: {str(e)}")

@app.post("/add_medication")
async def add_medication(request: Request):
    try:
        raw_data = await request.json()
        print("Received raw data:", json.dumps(raw_data, indent=2))
        med = Medication(**raw_data)
        print(f"Validated medication data: {med.dict()}")

        doc = {
            "user_id": med.user_id,
            "sfda_drug_id": med.sfda_drug_id,
            "drug_trade_name": med.drug_trade_name,
            "drug_scientific_name": med.drug_scientific_name,
            "drug_duration_start_date": med.drug_duration_start_date,
            "drug_duration_end_date": med.drug_duration_end_date,
            "processed": med.processed,
            "integrated": med.integrated,
        }
        result = user_medications_col.insert_one(doc)
        print(f"DEBUG: Medication inserted with ID: {result.inserted_id}")
        return {"message": "Medication added successfully.", "inserted_id": str(result.inserted_id)}
    except HTTPException as e:
        raise e
    except Exception as e:
        print("Error inserting medication:", e)
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@app.get("/get_medications")
def get_medications(user_id: str = "1"):
    try:
        meds = list(user_medications_col.find({"user_id": user_id}))
        print(f"📦 Total medications found for user {user_id}: {len(meds)}")
        for med in meds:
            med["_id"] = str(med["_id"])
        return {"count": len(meds), "medications": meds}
    except Exception as e:
        print("Error fetching medications:", e)
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/delete_medication")
def delete_medication(data: dict = Body(...)):
    try:
        med_id = data.get("_id")
        if not med_id:
            raise HTTPException(status_code=400, detail="Medication _id is required for deletion.")

        med_doc = user_medications_col.find_one({"_id": ObjectId(med_id)})
        if not med_doc:
            raise HTTPException(status_code=404, detail="No matching medication found.")

        med_result = user_medications_col.delete_one({"_id": ObjectId(med_id)})
        if med_result.deleted_count == 1:
            trade_name = med_doc.get("drug_trade_name")
            user_id = med_doc.get("user_id")
            inter_result = drug_food_interactions_col.delete_many(
                {"drug_trade_name": trade_name, "user_id": user_id}
            )
            print(f"DEBUG: Deleted medication {med_id} and {inter_result.deleted_count} related interactions")
            return {"message": "Medication and related interactions deleted successfully."}

        print(f"DEBUG: No medication matched _id {med_id}")
        return {"message": "No matching medication found."}
    except Exception as e:
        print("Error deleting medication:", e)
        raise HTTPException(status_code=500, detail=str(e))
