
import os
from datetime import datetime, timezone
from pymongo import MongoClient

import firebase_admin
from firebase_admin import messaging
from firebase_functions import pubsub_fn

# Initialize Firebase Admin SDK (Cloud Functions handles credentials automatically)
if not firebase_admin._apps:
    firebase_admin.initialize_app()

# --- MongoDB Setup for Cloud Function: Reads from Firebase Functions Environment Variable ---
mongo_uri = os.environ.get("MONGO_URI")
mongo_client = None

if mongo_uri:
    try:
        mongo_client = MongoClient(mongo_uri)
        db_cf = mongo_client["DFIchecker"] # Use your main database name
        drug_food_interactions_col_cf = db_cf["drug_food_interactions"]
        user_fcm_tokens_col_cf = db_cf["user_fcm_tokens"]
    except Exception as e:
        print(f"ERROR: Failed to connect to MongoDB in Cloud Function: {e}")
else:
    print("WARNING: MONGO_URI environment variable not set for Cloud Function.")

@pubsub_fn.on_schedule(schedule="every day 10:00")
def daily_interaction_reminder(event: pubsub_fn.ScheduledEvent):
    print("Daily interaction reminder Cloud Function triggered.")
    
    if not mongo_client:
        print("MongoDB not initialized. Aborting daily reminder.")
        return

    today = datetime.now(timezone.utc)
    
    users_with_active_interactions = drug_food_interactions_col_cf.aggregate([
        {
            "$match": {
                "$or": [
                    {"drug_duration_end_date": None},
                    {"drug_duration_end_date": {"$gte": today}}
                ]
            }
        },
        { "$group": { "_id": "$user_id" } }
    ])

    user_ids_to_notify = [user["_id"] for user in users_with_active_interactions]
    print(f"Found {len(user_ids_to_notify)} users with active interactions for daily reminder.")

    if not user_ids_to_notify:
        print("No active interactions found. Skipping daily reminder notifications.")
        return

    for user_id in user_ids_to_notify:
        user_tokens_docs = user_fcm_tokens_col_cf.find({"user_id": user_id})
        registration_tokens = [doc["fcm_token"] for doc in user_tokens_docs if "fcm_token" in doc]
        
        if not registration_tokens:
            print(f"No FCM token found for user {user_id}. Skipping daily notification.")
            continue

        message = messaging.Message(
            notification=messaging.Notification(
                title="سالم", # Your specified title
                body="سلامتك اهم، شيّك إذا في تعارضات مع دواك", # Your specified body
            ),
            data={ "type": "daily_reminder", "user_id": user_id },
            tokens=registration_tokens, 
        )

        try:
            response = messaging.send_each(messages=[message]) 
            print(f"FCM: Sent daily reminder to {user_id} ({len(registration_tokens)} devices): {response}")
        except Exception as e:
            print(f"FCM Error: Failed to send daily reminder to {user_id}: {e}")

    print("Daily interaction reminder Cloud Function completed.")


