from fastapi import FastAPI, HTTPException
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from pydantic import BaseModel
from typing import Optional, List
import re

# ---------------- MongoDB Setup ----------------
mongo_uri = "mongodb+srv://dfi-user:UwXxlbp6C3uZTE50@dfisaudi.e7wbnvh.mongodb.net/?retryWrites=true&w=majority&appName=DFISaudi"
client = MongoClient(mongo_uri)

db = client["DFIchecker"]
user_medications_col = db["user_medication_list"]
drug_food_interactions_col = db["drug_food_interactions"]

sfda_col = client["SFDA"]["SFDA_drugs"]
food_interactions_col = client["knowledge"]["food_interactions"]

# ---------------- FastAPI Setup ----------------
app = FastAPI()


# ---------------- Pydantic Models ----------------
class ProcessRequest(BaseModel):
    user_id: str


# ---------------- Helper Functions ----------------
def find_scientific_names(trade_name: str):
    docs = list(sfda_col.find({
        "trade_name": {
            "$regex": f"^{re.escape(trade_name)}$",
            "$options": "i"
        }
    }))
    names = []
    for doc in docs:
        sci = doc.get("scientific_name", "")
        parts = [x.strip() for x in sci.split(",") if x.strip()]
        names.extend(parts)
    return list(set(names))


def find_interactions(scientific_name: str):
    return list(food_interactions_col.find({
        "drug_name": {
            "$regex": rf"\b{re.escape(scientific_name)}\b",
            "$options": "i"
        }
    }))


def store_interaction(interaction, user_id, trade_name, duration_end):
    entry = {
        "user_id": user_id,
        "drug_id": interaction.get("drug_id", ""),
        "interaction_food": interaction.get("interaction_food", "").strip(),
        "description": interaction.get("description", ""),
        "severity": interaction.get("severity", "N/A"),
        "drug_trade_name": trade_name,
        "drug_duration_end_date": duration_end
    }
    try:
        drug_food_interactions_col.insert_one(entry)
    except DuplicateKeyError:
        pass


def process_user_medications(user_id: str):
    user_meds = list(user_medications_col.find({
        "user_id": user_id,
        "processed": 0
    }))

    if not user_meds:
        return {"message": "No unprocessed medications for this user."}

    stored_count = 0
    for med in user_meds:
        trade_name = med.get("drug_trade_name", "").strip()
        duration_end = med.get("drug_duration_end_date", None)
        if not trade_name:
            continue

        scientific_names = find_scientific_names(trade_name)
        for sci in scientific_names:
            interactions = find_interactions(sci)
            for inter in interactions:
                store_interaction(inter, user_id, trade_name, duration_end)
                stored_count += 1

        user_medications_col.update_one(
            {"_id": med["_id"]},
            {"$set": {"processed": 1}}
        )

    return {"message": f"Processed successfully. {stored_count} interactions stored."}


# ---------------- API Routes ----------------
@app.post("/process/")
def process_user(request: ProcessRequest):
    try:
        result = process_user_medications(request.user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
