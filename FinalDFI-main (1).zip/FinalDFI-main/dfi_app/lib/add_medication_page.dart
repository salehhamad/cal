import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_typeahead/flutter_typeahead.dart';

final String baseUrl = "https://finaldfi.onrender.com";
final String userId = "1";

// Modern Medical Theme Colors
class AppColors {
  // Light Theme - Modern Healthcare
  static const Color medicalBlue = Color(0xFF1A73E8);
  static const Color lightBlue = Color(0xFF4285F4);
  static const Color lightBackground = Color(0xFFF8F9FA);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightText = Color(0xFF202124);
  static const Color lightTextSecondary = Color(0xFF5F6368);
  static const Color lightBorder = Color(0xFFE8EAED);

  // Dark Theme - Premium
  static const Color premiumCyan = Color(0xFF00D4FF);
  static const Color darkCyan = Color(0xFF00BCD4);
  static const Color darkBackground = Color(0xFF121212);
  static const Color darkSurface = Color(0xFF1E1E1E);
  static const Color darkCard = Color(0xFF2D2D2D);
  static const Color darkText = Color(0xFFFFFFFF);
  static const Color darkTextSecondary = Color(0xFFB3B3B3);
  static const Color darkBorder = Color(0xFF404040);

  // Status Colors
  static const Color successGreen = Color(0xFF34A853);
  static const Color errorRed = Color(0xFFEA4335);

  // Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [medicalBlue, lightBlue],
  );

  static const LinearGradient darkGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [premiumCyan, darkCyan],
  );
}

class AddMedicationPage extends StatefulWidget {
  const AddMedicationPage({Key? key}) : super(key: key);

  @override
  _AddMedicationPageState createState() => _AddMedicationPageState();
}

class _AddMedicationPageState extends State<AddMedicationPage>
    with TickerProviderStateMixin {
  final _tradeController = TextEditingController();
  final _scientificController = TextEditingController();
  final _startDateController = TextEditingController();
  final _endDateController = TextEditingController();

  String? _sfdaDrugId;
  DateTime? _startDate;
  DateTime? _endDate;
  bool _isLoading = false;

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  List<Medication> medications = [];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutQuart,
      ),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _tradeController.dispose();
    _scientificController.dispose();
    _startDateController.dispose();
    _endDateController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<List<Map<String, dynamic>>> autocomplete(String query) async {
    if (query.isEmpty) return [];
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/autocomplete?q=${Uri.encodeComponent(query)}"),
      );
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(
          jsonDecode(response.body)['results'],
        );
      }
    } catch (e) {
      print("خطأ في البحث التلقائي: $e");
    }
    return [];
  }

  Future<Map<String, dynamic>> autofill(String name) async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/autofill?input_name=${Uri.encodeComponent(name)}"),
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
    } catch (e) {
      print("خطأ في التعبئة التلقائية: $e");
    }
    return {};
  }

  Future<void> _pickDate(bool isStart) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    DateTime? date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: isDark
                ? const ColorScheme.dark(
                    primary: AppColors.premiumCyan,
                    onPrimary: Colors.black,
                    surface: AppColors.darkCard,
                    onSurface: AppColors.darkText,
                  )
                : const ColorScheme.light(
                    primary: AppColors.medicalBlue,
                    onPrimary: Colors.white,
                    surface: AppColors.lightSurface,
                    onSurface: AppColors.lightText,
                  ),
          ),
          child: child!,
        );
      },
    );

    if (date != null) {
      setState(() {
        if (isStart) {
          _startDate = date;
          _startDateController.text = _formatDate(date);
        } else {
          _endDate = date;
          _endDateController.text = _formatDate(date);
        }
      });
    }
  }

  String _formatDate(DateTime date) =>
      "${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}";

  void _handleSubmit() async {
    if (_tradeController.text.isEmpty || _scientificController.text.isEmpty) {
      _showSnackBar('يرجى ملء جميع الحقول المطلوبة', isError: true);
      return;
    }

    setState(() => _isLoading = true);

    try {
      final med = Medication(
        id: '',
        userId: userId,
        sfdaDrugId: _sfdaDrugId ?? '',
        tradeName: _tradeController.text,
        scientificName: _scientificController.text,
        startDate: _startDate ?? DateTime.now(),
        endDate: _endDate,
        integrated: false,
        processed: 0,
      );

      await addMedication(med);

      if (mounted) {
        Navigator.pop(context, true); // Return true to indicate success
      }
    } catch (e) {
      _showSnackBar('حدث خطأ أثناء إضافة الدواء', isError: true);
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> addMedication(Medication med) async {
    final response = await http.post(
      Uri.parse("$baseUrl/add_medication"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(med.toJson()),
    );

    if (response.statusCode == 200) {
      _showSnackBar('تم إضافة الدواء بنجاح!');
    } else {
      throw Exception('فشل في إضافة الدواء');
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;

    final isDark = Theme.of(context).brightness == Brightness.dark;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: isError ? AppColors.errorRed : AppColors.successGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  Widget _buildModernTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool readOnly = false,
    VoidCallback? onTap,
    bool isTypeAhead = false,
    Widget? typeAheadField,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (isTypeAhead && typeAheadField != null) {
      return typeAheadField;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: isDark
                ? Colors.black.withOpacity(0.3)
                : Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        readOnly: readOnly,
        onTap: onTap,
        textDirection: TextDirection.rtl,
        style: TextStyle(
          color: isDark ? AppColors.darkText : AppColors.lightText,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            color:
                isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary,
            fontSize: 16,
          ),
          prefixIcon: Icon(
            icon,
            color: isDark ? AppColors.premiumCyan : AppColors.medicalBlue,
          ),
          filled: true,
          fillColor: isDark ? AppColors.darkCard : AppColors.lightSurface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(
              color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
              width: 1,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(
              color: isDark ? AppColors.premiumCyan : AppColors.medicalBlue,
              width: 2,
            ),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        ),
      ),
    );
  }

  Widget _buildTypeAheadField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: isDark
                ? Colors.black.withOpacity(0.3)
                : Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: TypeAheadField<Map<String, dynamic>>(
        textFieldConfiguration: TextFieldConfiguration(
          controller: controller,
          textDirection: TextDirection.rtl,
          style: TextStyle(
            color: isDark ? AppColors.darkText : AppColors.lightText,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
          decoration: InputDecoration(
            labelText: label,
            labelStyle: TextStyle(
              color: isDark
                  ? AppColors.darkTextSecondary
                  : AppColors.lightTextSecondary,
              fontSize: 16,
            ),
            prefixIcon: Icon(
              icon,
              color: isDark ? AppColors.premiumCyan : AppColors.medicalBlue,
            ),
            filled: true,
            fillColor: isDark ? AppColors.darkCard : AppColors.lightSurface,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(
                color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
                width: 1,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(
                color: isDark ? AppColors.premiumCyan : AppColors.medicalBlue,
                width: 2,
              ),
            ),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          ),
        ),
        suggestionsCallback: (pattern) async {
          if (pattern.length < 2) return [];
          return await autocomplete(pattern);
        },
        itemBuilder: (context, suggestion) {
          return Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: isDark ? AppColors.darkCard : AppColors.lightSurface,
              border: Border(
                bottom: BorderSide(
                  color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
                  width: 0.5,
                ),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  suggestion['trade_name'] ?? '',
                  style: TextStyle(
                    color: isDark ? AppColors.darkText : AppColors.lightText,
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                  textDirection: TextDirection.rtl,
                ),
                const SizedBox(height: 4),
                Text(
                  suggestion['scientific_name'] ?? '',
                  style: TextStyle(
                    color: isDark
                        ? AppColors.darkTextSecondary
                        : AppColors.lightTextSecondary,
                    fontSize: 14,
                  ),
                  textDirection: TextDirection.rtl,
                ),
              ],
            ),
          );
        },
        onSuggestionSelected: (suggestion) async {
          final auto = await autofill(
            suggestion['trade_name'] ?? suggestion['scientific_name'],
          );
          setState(() {
            _sfdaDrugId = auto['sfda_drug_id'] ?? '';
            _tradeController.text = auto['trade_name'] ?? '';
            _scientificController.text = auto['scientific_name'] ?? '';
          });
        },
        suggestionsBoxDecoration: SuggestionsBoxDecoration(
          borderRadius: BorderRadius.circular(16),
          elevation: 8,
          color: isDark ? AppColors.darkCard : AppColors.lightSurface,
        ),
        noItemsFoundBuilder: (context) => Container(
          padding: const EdgeInsets.all(16),
          child: Text(
            'لا توجد نتائج',
            style: TextStyle(
              color: isDark
                  ? AppColors.darkTextSecondary
                  : AppColors.lightTextSecondary,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String text,
    required VoidCallback onPressed,
    required bool isPrimary,
    bool isLoading = false,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Expanded(
      child: Container(
        height: 56,
        decoration: BoxDecoration(
          gradient: isPrimary
              ? (isDark ? AppColors.darkGradient : AppColors.primaryGradient)
              : null,
          color: isPrimary ? null : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: isPrimary
              ? null
              : Border.all(
                  color: AppColors.errorRed,
                  width: 2,
                ),
          boxShadow: isPrimary
              ? [
                  BoxShadow(
                    color: (isDark
                            ? AppColors.premiumCyan
                            : AppColors.medicalBlue)
                        .withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: isLoading ? null : onPressed,
            borderRadius: BorderRadius.circular(16),
            child: Container(
              alignment: Alignment.center,
              child: isLoading && isPrimary
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : Text(
                      text,
                      style: TextStyle(
                        color: isPrimary ? Colors.white : AppColors.errorRed,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor:
            isDark ? AppColors.darkBackground : AppColors.lightBackground,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          title: Text(
            'إضافة دواء',
            style: TextStyle(
              color: isDark ? AppColors.darkText : AppColors.lightText,
              fontSize: 24,
              fontWeight: FontWeight.w700,
            ),
          ),
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_ios,
              color: isDark ? AppColors.darkText : AppColors.lightText,
            ),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        body: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      gradient: isDark
                          ? AppColors.darkGradient
                          : AppColors.primaryGradient,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: (isDark
                                  ? AppColors.premiumCyan
                                  : AppColors.medicalBlue)
                              .withOpacity(0.3),
                          blurRadius: 15,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(
                          Icons.medication_rounded,
                          color: Colors.white,
                          size: 32,
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'إضافة دواء جديد',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'يرجى ملء المعلومات التالية لإضافة دوائك الجديد',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9),
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 32),

                  // Form Fields
                  _buildTypeAheadField(
                    controller: _tradeController,
                    label: 'الاسم التجاري',
                    icon: Icons.local_pharmacy_rounded,
                  ),
                  _buildTypeAheadField(
                    controller: _scientificController,
                    label: 'الاسم العلمي',
                    icon: Icons.science_rounded,
                  ),
                  _buildModernTextField(
                    controller: _startDateController,
                    label: 'تاريخ البدء',
                    icon: Icons.event_rounded,
                    readOnly: true,
                    onTap: () => _pickDate(true),
                  ),
                  _buildModernTextField(
                    controller: _endDateController,
                    label: 'تاريخ الانتهاء',
                    icon: Icons.event_available_rounded,
                    readOnly: true,
                    onTap: () => _pickDate(false),
                  ),

                  const SizedBox(height: 32),

                  // Action Buttons
                  Row(
                    children: [
                      _buildActionButton(
                        text: 'إلغاء',
                        onPressed: () => Navigator.pop(context),
                        isPrimary: false,
                      ),
                      const SizedBox(width: 16),
                      _buildActionButton(
                        text: 'تأكيد',
                        onPressed: _handleSubmit,
                        isPrimary: true,
                        isLoading: _isLoading,
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> fetchMedications() async {
    try {
      final response = await http
          .get(Uri.parse("$baseUrl/get_medications?user_id=$userId"));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['medications'] != null) {
          final List<dynamic> medsJson = data['medications'];
          if (mounted) {
            setState(() {
              medications =
                  medsJson.map((med) => Medication.fromJson(med)).toList();
            });
          }
        }
      }
    } catch (e) {
      print("خطأ في جلب الأدوية: $e");
    }
  }
}

// Medication class
class Medication {
  final String id;
  final String userId;
  final String sfdaDrugId;
  final String tradeName;
  final String scientificName;
  final DateTime startDate;
  final DateTime? endDate;
  final bool integrated;
  final int processed;

  Medication({
    required this.id,
    required this.userId,
    required this.sfdaDrugId,
    required this.tradeName,
    required this.scientificName,
    required this.startDate,
    required this.endDate,
    required this.integrated,
    required this.processed,
  });

  factory Medication.fromJson(Map<String, dynamic> json) {
    return Medication(
      id: json['_id'] ?? '',
      userId: json['user_id'] ?? "1",
      sfdaDrugId: json['sfda_drug_id'] ?? '',
      tradeName: json['drug_trade_name'] ?? '',
      scientificName: json['drug_scientific_name'] ?? '',
      startDate: DateTime.parse(json['drug_duration_start_date']),
      endDate: json['drug_duration_end_date'] != null
          ? DateTime.parse(json['drug_duration_end_date'])
          : null,
      integrated: json['integrated'] ?? true,
      processed: json['processed'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "user_id": userId,
      "sfda_drug_id": sfdaDrugId,
      "drug_trade_name": tradeName,
      "drug_scientific_name": scientificName,
      "drug_duration_start_date": startDate.toIso8601String(),
      "drug_duration_end_date": endDate?.toIso8601String(),
      "processed": processed,
      "integrated": integrated,
    };
  }
}