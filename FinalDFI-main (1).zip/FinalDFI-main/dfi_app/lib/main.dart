// main.dart
import 'package:flutter/material.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'home_screen.dart';
import 'app_theme.dart';



const String baseUrl = 'https://finaldfi.onrender.com';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize OneSignal with your actual App ID
  OneSignal.initialize('45eb09e1-b8d5-4b58-890d-7b4eee3b21f4');

  // Request permission for notifications
  OneSignal.Notifications.requestPermission(true);

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isDarkMode = false;

  @override
  void initState() {
    super.initState();
    setupOneSignal();
  }

  void setupOneSignal() {
    // Handle notification received while app is in foreground
    OneSignal.Notifications.addForegroundWillDisplayListener((event) {
      print('Notification received in foreground: ${event.notification.title}');
      // Display the notification even when app is in foreground
      event.notification.display();
    });

    // Handle notification tapped/opened
    OneSignal.Notifications.addClickListener((event) {
      print('Notification clicked: ${event.notification.title}');
      // Handle navigation based on notification data
      final data = event.notification.additionalData;
      if (data != null) {
        if (data['type'] == 'new_interaction') {
          print('New interaction notification clicked');
          // Navigate to interactions tab
        } else if (data['type'] == 'daily_reminder') {
          print('Daily reminder notification clicked');
          // Navigate to interactions tab
        }
      }
    });

    // Register the device with your backend when OneSignal ID is available
    OneSignal.User.pushSubscription.addObserver((state) {
      print('OneSignal subscription state changed: ${state.current.id}');
      if (state.current.id != null && state.current.id!.isNotEmpty) {
        registerOneSignalToken(state.current.id!);
      }
    });

    // Also try to get the current subscription ID immediately
    _getCurrentSubscriptionId();
  }

  // Get current subscription ID if available
  Future<void> _getCurrentSubscriptionId() async {
    try {
      final subscriptionId = OneSignal.User.pushSubscription.id;
      if (subscriptionId != null && subscriptionId.isNotEmpty) {
        print('Current OneSignal subscription ID: $subscriptionId');
        await registerOneSignalToken(subscriptionId);
      } else {
        print('OneSignal subscription ID not available yet');
      }
    } catch (e) {
      print('Error getting OneSignal subscription ID: $e');
    }
  }

  // Register OneSignal player ID with your backend
  Future<void> registerOneSignalToken(String playerId) async {
    try {
      print('Registering OneSignal player ID: $playerId');

      final response = await http.post(
        Uri.parse('$baseUrl/register_onesignal_token/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': '1', // Your static user ID
          'player_id': playerId,
        }),
      );

      if (response.statusCode == 200) {
        print('OneSignal player ID registered successfully');
      } else {
        print(
          'Failed to register OneSignal player ID: ${response.statusCode} - ${response.body}',
        );
      }
    } catch (e) {
      print('Error registering OneSignal player ID: $e');
    }
  }

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سالم - مراقب التفاعلات الدوائية',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: _isDarkMode ? ThemeMode.dark : ThemeMode.light,
      home: FoodInteractionScreen(onThemeToggle: _toggleTheme),
      // RTL handling remains on individual screens
    );
  }
}
