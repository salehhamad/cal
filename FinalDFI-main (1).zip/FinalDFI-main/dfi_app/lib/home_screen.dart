import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'add_medication_page.dart';

final String baseUrl = "https://finaldfi.onrender.com";

// Modern Medical Theme Colors
class AppColors {
  // Light Theme - Modern Healthcare
  static const Color medicalBlue = Color(0xFF1A73E8);
  static const Color lightBlue = Color(0xFF4285F4);
  static const Color lightBackground = Color(0xFFF8F9FA);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightCard = Color(0xFFFFFFFF);
  static const Color lightText = Color(0xFF202124);
  static const Color lightTextSecondary = Color(0xFF5F6368);
  static const Color lightBorder = Color(0xFFE8EAED);
  static const Color lightDivider = Color(0xFFDEE2E6);

  // Dark Theme - Premium
  static const Color premiumCyan = Color(0xFF00D4FF);
  static const Color darkCyan = Color(0xFF00BCD4);
  static const Color darkBackground = Color(0xFF121212);
  static const Color darkSurface = Color(0xFF1E1E1E);
  static const Color darkCard = Color(0xFF2D2D2D);
  static const Color darkText = Color(0xFFFFFFFF);
  static const Color darkTextSecondary = Color(0xFFB3B3B3);
  static const Color darkBorder = Color(0xFF404040);
  static const Color darkDivider = Color(0xFF505050);

  // Status Colors
  static const Color dangerRed = Color(0xFFEA4335);
  static const Color warningOrange = Color(0xFFFF9800);
  static const Color successGreen = Color(0xFF34A853);

  // Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [medicalBlue, lightBlue],
  );

  static const LinearGradient darkGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [premiumCyan, darkCyan],
  );

  static const LinearGradient dangerGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFFF4757), Color(0xFFEA4335)],
  );

  static const LinearGradient warningGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFFFA726), Color(0xFFFF9800)],
  );

  static const LinearGradient successGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF66BB6A), Color(0xFF34A853)],
  );
}

class Interaction {
  final String id;
  final String interactionFood;
  final String description;
  final String severity;
  final String tradeName;
  final String durationEnd;
  final String drugId;
  final bool submitted;

  Interaction({
    required this.id,
    required this.interactionFood,
    required this.description,
    required this.severity,
    required this.tradeName,
    required this.durationEnd,
    required this.drugId,
    this.submitted = false,
  });

  @override
  String toString() {
    return 'Interaction{id: $id, interactionFood: $interactionFood, description: $description, severity: $severity, tradeName: $tradeName, durationEnd: $durationEnd, drugId: $drugId, submitted: $submitted}';
  }

  factory Interaction.fromJson(Map<String, dynamic> json) {
    return Interaction(
      id: json['_id'] ?? '',
      interactionFood: json['interaction_food'] ?? '',
      description: json['description'] ?? '',
      severity: json['severity'] ?? '',
      tradeName: json['drug_trade_name'] ?? '',
      durationEnd: json['drug_duration_end_date'] ?? '',
      drugId: json['drug_id'] ?? '',
      submitted: json['submitted'] ?? false,
    );
  }
}

class Feedback {
  final String userId;
  final String drugId;
  final String interactionFood;
  final String description;
  final String severity;
  final String drugTradeName;
  final DateTime drugDurationEndDate;
  final String userAnswer;
  final DateTime createdAt;

  Feedback({
    required this.userId,
    required this.drugId,
    required this.interactionFood,
    required this.description,
    required this.severity,
    required this.drugTradeName,
    required this.drugDurationEndDate,
    required this.userAnswer,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'drug_id': drugId,
      'interaction_food': interactionFood,
      'description': description,
      'severity': severity,
      'drug_trade_name': drugTradeName,
      'drug_duration_end_date': drugDurationEndDate.toIso8601String(),
      'user_answer': userAnswer,
      'created_at': createdAt.toIso8601String(),
    };
  }
}

class FoodInteractionScreen extends StatefulWidget {
  final VoidCallback? onThemeToggle;

  const FoodInteractionScreen({Key? key, this.onThemeToggle}) : super(key: key);

  @override
  _FoodInteractionScreenState createState() => _FoodInteractionScreenState();
}

class _FoodInteractionScreenState extends State<FoodInteractionScreen>
    with TickerProviderStateMixin {
  int selectedTab = 0;
  List<Interaction> interactions = [];
  List<Medication> medications = [];
  List<bool> expanded = [];
  List<bool> submitted = [];
  bool isLoading = true;
  final String userId = "1";

  late AnimationController _headerAnimationController;
  late AnimationController _cardAnimationController;
  late Animation<double> _headerFadeAnimation;
  late Animation<double> _headerSlideAnimation;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    processUserAndLoadInteractions();
    fetchMedications();
  }

  void _setupAnimations() {
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );

    _cardAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _headerFadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeInOut,
    ));

    _headerSlideAnimation = Tween<double>(
      begin: -50.0,
      end: 0.0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutQuart,
    ));

    _headerAnimationController.forward();
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _cardAnimationController.dispose();
    super.dispose();
  }

  // OneSignal notification helper
  void showOneSignalNotification(String title, String message) {
    // You can integrate real OneSignal logic if needed.
    print('OneSignal notification: $title - $message');
  }

  Future<void> processUserAndLoadInteractions() async {
    if (mounted) setState(() => isLoading = true);

    try {
      final processResponse = await http.post(
        Uri.parse('$baseUrl/process/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': userId}),
      );

      if (processResponse.statusCode != 200) {
        print('Process failed: ${processResponse.statusCode} ${processResponse.body}');
        if (mounted) {
          setState(() {
            interactions = [];
            expanded = [];
            submitted = [];
            isLoading = false;
          });
        }
        return;
      }

      final interactionsResponse = await http.get(
        Uri.parse('$baseUrl/interactions?user_id=$userId'),
      );

      if (interactionsResponse.statusCode == 200) {
        final decoded = jsonDecode(interactionsResponse.body);
        final List<dynamic> jsonList = decoded is List ? decoded : <dynamic>[];

        List<Interaction> items = jsonList
            .map((j) => Interaction.fromJson(j as Map<String, dynamic>))
            .toList();

        int previousCount = interactions.length;

        int priority(String s) {
          if (s == 'خطير') return 0;
          if (s == 'متوسط') return 1;
          return 2;
        }

        items.sort((a, b) => priority(a.severity).compareTo(priority(b.severity)));

        if (mounted) {
          setState(() {
            interactions = items;
            expanded = List<bool>.filled(interactions.length, false);
            submitted = List<bool>.filled(interactions.length, false);
            isLoading = false;
          });
          _cardAnimationController.forward();
        }

        if (items.isNotEmpty) {
          if (previousCount > 0 && items.length > previousCount) {
            int newCount = items.length - previousCount;
            showOneSignalNotification(
              'تعارضات غذائية جديدة',
              'تم العثور على $newCount تعارض غذائي جديد. تحقق من قائمتك.',
            );
          }
        }

        print('Fetched Interactions count: ${items.length}');
      } else {
        print('Failed to load interactions: ${interactionsResponse.statusCode}');
        if (mounted) {
          setState(() {
            interactions = [];
            expanded = [];
            submitted = [];
            isLoading = false;
          });
        }
      }
    } catch (e) {
      print('Error in processUserAndLoadInteractions: $e');
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> fetchMedications() async {
    try {
      final response =
          await http.get(Uri.parse('$baseUrl/get_medications?user_id=$userId'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print("Fetched Medications: $data");

        if (data['medications'] != null) {
          final List<dynamic> medsJson = data['medications'];
          if (mounted) {
            setState(() {
              medications =
                  medsJson.map((med) => Medication.fromJson(med)).toList();
            });
          }
        } else {
          print("No medications found in the response.");
        }
      } else {
        print("Failed to fetch medications. Status code: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching medications: $e");
    }
  }

  void toggleExpand(int index) {
    setState(() => expanded[index] = !expanded[index]);
  }

  void submitSurvey(int index, String userAnswer) {
    setState(() => submitted[index] = true);

    DateTime now = DateTime.now();

    try {
      DateTime parsedEndDate;
      if (interactions[index].durationEnd.isNotEmpty) {
        parsedEndDate = DateTime.parse(interactions[index].durationEnd);
      } else {
        parsedEndDate = now;
      }

      Feedback feedback = Feedback(
        userId: userId,
        drugId: interactions[index].drugId,
        interactionFood: interactions[index].interactionFood,
        description: interactions[index].description,
        severity: interactions[index].severity,
        drugTradeName: interactions[index].tradeName,
        drugDurationEndDate: parsedEndDate,
        userAnswer: userAnswer,
        createdAt: now,
      );

      submitFeedback(feedback, interactions[index].id);
    } catch (e) {
      print("Error during date parsing: $e");
    }
  }

  Future<void> submitFeedback(Feedback feedback, String interactionId) async {
    try {
      Map<String, dynamic> requestBody = {
        'feedback': feedback.toJson(),
        'interaction_id': interactionId,
      };

      final response = await http.post(
        Uri.parse('$baseUrl/submit_feedback/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        print("Feedback submitted successfully!");
        await processUserAndLoadInteractions();
      } else {
        print("Failed to submit feedback: ${response.statusCode}");
      }
    } catch (e) {
      print("Error submitting feedback: $e");
    }
  }

  String calculateDuration(DateTime startDate, DateTime? endDate) {
    if (endDate == null) {
      return "غير محدد المدة";
    }

    final difference = endDate.difference(startDate);
    int days = difference.inDays;

    if (days == 1) {
      return 'يوم';
    } else if (days == 2) {
      return 'يومين';
    } else if (days < 30) {
      return '$days يوم';
    }

    int months = (days / 30).floor();
    if (months == 1) {
      return 'شهر';
    } else if (months == 2) {
      return 'شهرين';
    } else if (months > 2 && months < 12) {
      return '$months شهور';
    }

    if (days >= 365) {
      int years = (days / 365).floor();
      if (years == 1) {
        return 'سنة';
      } else if (years == 2) {
        return 'سنتين';
      } else {
        return '$years سنوات';
      }
    }

    return '$days يوم';
  }

  Future<void> _confirmDelete(Medication med) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: isDark ? AppColors.darkCard : AppColors.lightSurface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text(
            "حذف الدواء",
            style: TextStyle(
              color: isDark ? AppColors.darkText : AppColors.lightText,
              fontWeight: FontWeight.w600,
            ),
          ),
          content: Text(
            "هل أنت متأكد أنك تريد حذف هذا الدواء؟",
            style: TextStyle(
              color: isDark
                  ? AppColors.darkTextSecondary
                  : AppColors.lightTextSecondary,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(
                "لا",
                style: TextStyle(
                  color: isDark
                      ? AppColors.darkTextSecondary
                      : AppColors.lightTextSecondary,
                ),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(
                "نعم",
                style: TextStyle(
                    color: AppColors.dangerRed, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      try {
        await http.delete(
          Uri.parse('$baseUrl/delete_medication'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'_id': med.id}),
        );
        setState(() => medications.remove(med));
        await processUserAndLoadInteractions();
      } catch (e) {
        print("Error deleting medication: $e");
      }
    }
  }

  Future<void> addMedication(Medication med) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/add_medication'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(med.toJson()),
      );

      if (response.statusCode == 200) {
        print("Medication added successfully");
      } else {
        print("Failed to add medication: ${response.statusCode}");
      }
    } catch (e) {
      print("Error adding medication: $e");
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return "غير محدد";
    return "${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}";
  }

  Widget _buildNotificationBadge() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final activeInteractions = interactions.where((i) => !i.submitted).length;

    return AnimatedBuilder(
      animation: _headerFadeAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _headerSlideAnimation.value),
          child: Opacity(
            opacity: _headerFadeAnimation.value,
            child: Container(
              decoration: BoxDecoration(
                gradient: activeInteractions > 0
                    ? AppColors.dangerGradient
                    : AppColors.successGradient,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: (activeInteractions > 0
                            ? AppColors.dangerRed
                            : AppColors.successGreen)
                        .withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    activeInteractions > 0
                        ? Icons.warning_rounded
                        : Icons.check_circle_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '$activeInteractions',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(width: 12),
                  GestureDetector(
                    onTap: widget.onThemeToggle,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        isDark
                            ? Icons.light_mode_rounded
                            : Icons.dark_mode_rounded,
                        color: Colors.white,
                        size: 18,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatsSection() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final totalInteractions = interactions.length;
    final criticalInteractions =
        interactions.where((i) => i.severity == 'خطير').length;
    final activeMedications = medications.length;

    return AnimatedBuilder(
      animation: _headerFadeAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _headerSlideAnimation.value * 0.5),
          child: Opacity(
            opacity: _headerFadeAnimation.value,
            child: Container(
              margin: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Expanded(child: _buildStatCard("إجمالي التعارضات", totalInteractions.toString(), Icons.warning_rounded, isDark)),
                  const SizedBox(width: 12),
                  Expanded(child: _buildStatCard("تعارضات خطيرة", criticalInteractions.toString(), Icons.dangerous_rounded, isDark)),
                  const SizedBox(width: 12),
                  Expanded(child: _buildStatCard("ادويتي", activeMedications.toString(), Icons.medication_rounded, isDark)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatCard(
      String label, String value, IconData icon, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkCard : AppColors.lightSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color:
                isDark ? Colors.black.withOpacity(0.3) : Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient:
                  isDark ? AppColors.darkGradient : AppColors.primaryGradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            value,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              color: isDark ? AppColors.darkText : AppColors.lightText,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: isDark
                  ? AppColors.darkTextSecondary
                  : AppColors.lightTextSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabNavigation() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: isDark
            ? AppColors.darkCard.withOpacity(0.8)
            : AppColors.lightBorder.withOpacity(0.5),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(child: _buildTabButton(' قائمة التعارضات الدوائية و الغذائية', 0, isDark)),
          Expanded(child: _buildTabButton('أدويتي', 1, isDark)),
        ],
      ),
    );
  }

  Widget _buildTabButton(String text, int index, bool isDark) {
    final isSelected = selectedTab == index;

    return GestureDetector(
      onTap: () => setState(() => selectedTab = index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOutCubic,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient:
              isSelected ? (isDark ? AppColors.darkGradient : AppColors.primaryGradient) : null,
          borderRadius: BorderRadius.circular(12),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: (isDark ? AppColors.premiumCyan : AppColors.medicalBlue)
                        .withOpacity(0.4),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isSelected
                ? Colors.white
                : (isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary),
            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  Widget _buildInteractionCard(Interaction interaction, int index) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    LinearGradient severityGradient;
    switch (interaction.severity) {
      case 'خطير':
        severityGradient = AppColors.dangerGradient;
        break;
      case 'متوسط':
        severityGradient = AppColors.warningGradient;
        break;
      default:
        severityGradient = AppColors.successGradient;
    }

    return AnimatedContainer(
      duration: Duration(milliseconds: 300 + (index * 100)),
      curve: Curves.easeOutQuart,
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkCard : AppColors.lightSurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: isDark ? Colors.black.withOpacity(0.3) : Colors.black.withOpacity(0.08),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => toggleExpand(index),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: severityGradient,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: severityGradient.colors.first.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Text(
                        interaction.severity,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            interaction.interactionFood,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              color: isDark ? AppColors.darkText : AppColors.lightText,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            interaction.tradeName,
                            style: TextStyle(
                              color: isDark
                                  ? AppColors.darkTextSecondary
                                  : AppColors.lightTextSecondary,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: (isDark ? AppColors.premiumCyan : AppColors.medicalBlue)
                            .withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: AnimatedRotation(
                        turns: expanded[index] ? 0.5 : 0,
                        duration: const Duration(milliseconds: 300),
                        child: Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color:
                              isDark ? AppColors.premiumCyan : AppColors.medicalBlue,
                          size: 24,
                        ),
                      ),
                    ),
                  ],
                ),
                if (expanded[index]) ...[
                  const SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          (isDark ? AppColors.darkBorder : AppColors.lightBorder),
                          (isDark ? AppColors.darkBorder : AppColors.lightBorder)
                              .withOpacity(0.3),
                          (isDark ? AppColors.darkBorder : AppColors.lightBorder),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    interaction.description,
                    style: TextStyle(
                      color: isDark ? AppColors.darkTextSecondary : AppColors.lightText,
                      fontSize: 16,
                      height: 1.6,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  if (!interaction.submitted) ...[
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            (isDark ? AppColors.premiumCyan : AppColors.medicalBlue)
                                .withOpacity(0.1),
                            (isDark ? AppColors.premiumCyan : AppColors.medicalBlue)
                                .withOpacity(0.05),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: (isDark ? AppColors.premiumCyan : AppColors.medicalBlue)
                              .withOpacity(0.2),
                          width: 1,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "رأيك",
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                              color: isDark ? AppColors.darkText : AppColors.lightText,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "هل هذه المعلومة مفيدة؟",
                            style: TextStyle(
                              color: isDark
                                  ? AppColors.darkTextSecondary
                                  : AppColors.lightTextSecondary,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: _buildFeedbackButton(
                                  text: "نعم",
                                  onPressed: () => submitSurvey(index, "Yes"),
                                  isPositive: true,
                                  isDark: isDark,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _buildFeedbackButton(
                                  text: "لا",
                                  onPressed: () => submitSurvey(index, "No"),
                                  isPositive: false,
                                  isDark: isDark,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeedbackButton({
    required String text,
    required VoidCallback onPressed,
    required bool isPositive,
    required bool isDark,
  }) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        gradient:
            isPositive ? AppColors.successGradient : AppColors.dangerGradient,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: (isPositive ? AppColors.successGreen : AppColors.dangerRed)
                .withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            alignment: Alignment.center,
            child: Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMedicationCard(Medication med) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    String duration = calculateDuration(med.startDate, med.endDate);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkCard : AppColors.lightSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color:
                isDark ? Colors.black.withOpacity(0.3) : Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        title: Text(
          med.tradeName.isEmpty ? "لا يوجد اسم تجاري" : med.tradeName,
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 16,
            color: isDark ? AppColors.darkText : AppColors.lightText,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              "الاسم العلمي: ${med.scientificName.isEmpty ? 'غير متوفر' : med.scientificName}",
              style: TextStyle(
                color: isDark
                    ? AppColors.darkTextSecondary
                    : AppColors.lightTextSecondary,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              "مدة الاستخدام: $duration",
              style: TextStyle(
                color: isDark
                    ? AppColors.darkTextSecondary
                    : AppColors.lightTextSecondary,
                fontSize: 14,
              ),
            ),
          ],
        ),
        trailing: med.integrated == false
            ? Container(
                decoration: BoxDecoration(
                  color: AppColors.dangerRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: IconButton(
                  icon: const Icon(
                    Icons.delete_rounded,
                  ),
                  color: AppColors.dangerRed,
                  onPressed: () => _confirmDelete(med),
                ),
              )
            : null,
      ),
    );
  }

  Widget _buildEmptyState(String title, String subtitle) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Center(
      child: Container(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient:
                    isDark ? AppColors.darkGradient : AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(50),
              ),
              child: const Icon(
                Icons.medication_outlined,
                size: 48,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: isDark ? AppColors.darkText : AppColors.lightText,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 16,
                color: isDark
                    ? AppColors.darkTextSecondary
                    : AppColors.lightTextSecondary,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Center(
      child: Container(
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkCard : AppColors.lightSurface,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color:
                  isDark ? Colors.black.withOpacity(0.3) : Colors.black.withOpacity(0.1),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient:
                    isDark ? AppColors.darkGradient : AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Center(
                child: SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'جاري التحميل...',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: isDark ? AppColors.darkText : AppColors.lightText,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAddMedicationButton() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      height: 56,
      margin: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: isDark ? AppColors.darkGradient : AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: (isDark ? AppColors.premiumCyan : AppColors.medicalBlue)
                .withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _navigateToAddPage,
          borderRadius: BorderRadius.circular(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(
                Icons.add_rounded,
                color: Colors.white,
                size: 24,
              ),
              SizedBox(width: 8),
              Text(
                'إضافة دواء',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor:
            isDark ? AppColors.darkBackground : AppColors.lightBackground,
        body: SafeArea(
          child: Column(
            children: [
              // Header Section
              Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  gradient: AppColors.primaryGradient,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(32),
                    bottomRight: Radius.circular(32),
                  ),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'سالم',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 28,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        _buildNotificationBadge(),
                      ],
                    ),
                  ],
                ),
              ),

              // Stats Section
              _buildStatsSection(),

              // Tab Navigation
              _buildTabNavigation(),

              const SizedBox(height: 20),

              // Content Area
              Expanded(
                child: selectedTab == 0
                    ? isLoading
                        ? _buildLoadingIndicator()
                        : interactions.isEmpty
                            ? _buildEmptyState(
                                'لا توجد تعارضات غذائية',
                                'لم يتم الحصول على تعارضات بين أدويتك والأطعمة',
                              )
                            : ListView.builder(
                                itemCount: interactions.length,
                                itemBuilder: (context, index) {
                                  return _buildInteractionCard(
                                      interactions[index], index);
                                },
                              )
                    : medications.isEmpty
                        ? _buildEmptyState(
                            'لا توجد أدوية',
                            'ابدأ بإضافة أدويتك لمراقبة التعارضات',
                          )
                        : ListView.builder(
                            itemCount: medications.length,
                            itemBuilder: (context, index) {
                              return _buildMedicationCard(medications[index]);
                            },
                          ),
              ),

              // Add Medication Button (only show on medications tab)
              if (selectedTab == 1) _buildAddMedicationButton(),
            ],
          ),
        ),
      ),
    );
  }

  void _navigateToAddPage() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddMedicationPage()),
    );

    if (result == true) {
      await fetchMedications();
      await processUserAndLoadInteractions();
    }
  }
}

// Medication class
class Medication {
  final String id;
  final String userId;
  final String sfdaDrugId;
  final String tradeName;
  final String scientificName;
  final DateTime startDate;
  final DateTime? endDate;
  final bool integrated;
  final int processed;

  Medication({
    required this.id,
    required this.userId,
    required this.sfdaDrugId,
    required this.tradeName,
    required this.scientificName,
    required this.startDate,
    required this.endDate,
    required this.integrated,
    required this.processed,
  });

  factory Medication.fromJson(Map<String, dynamic> json) {
    return Medication(
      id: json['_id'] ?? '',
      userId: json['user_id'] ?? "1",
      sfdaDrugId: json['sfda_drug_id'] ?? '',
      tradeName: json['drug_trade_name'] ?? '',
      scientificName: json['drug_scientific_name'] ?? '',
      startDate: DateTime.parse(json['drug_duration_start_date']),
      endDate: json['drug_duration_end_date'] != null
          ? DateTime.tryParse(json['drug_duration_end_date'])
          : null,
      integrated: json['integrated'] ?? true,
      processed: json['processed'] ?? 0,
    );
    }

  Map<String, dynamic> toJson() {
    return {
      "user_id": userId,
      "sfda_drug_id": sfdaDrugId,
      "drug_trade_name": tradeName,
      "drug_scientific_name": scientificName,
      "drug_duration_start_date": startDate.toIso8601String(),
      "drug_duration_end_date": endDate?.toIso8601String(),
      "processed": processed,
      "integrated": integrated,
    };
  }
}